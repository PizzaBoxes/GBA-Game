DESCRIPTION:
This is the Friend Game! Your end goal is to explore a cave. Hint: bringing many friends along makes venturing into this giant cave a lot better! Cat and frog like to hang out in front of a cave, and you can choose to collect them as your friends. After you collect your friends, or don't, you can head into the cave.

CONTROLS:
Press START to begin playing and press SELECT any time to restart your adventure! Once playing, use the arrow keys to move--NOTE: you can only move by pressing ONE ARROW KEY AT A TIME. Diagonal movement is not supported! Touching cat or frog will collect them automatically.
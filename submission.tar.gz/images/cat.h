/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 cat cat.png 
 * Time-stamp: Monday 04/01/2024, 23:13:03
 * 
 * Image Information
 * -----------------
 * cat.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CAT_H
#define CAT_H

extern const unsigned short cat[256];
#define CAT_SIZE 512
#define CAT_LENGTH 256
#define CAT_WIDTH 16
#define CAT_HEIGHT 16

#endif


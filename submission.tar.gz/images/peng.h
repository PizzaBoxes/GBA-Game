/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 peng peng.png 
 * Time-stamp: Monday 04/01/2024, 18:35:52
 * 
 * Image Information
 * -----------------
 * peng.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PENG_H
#define PENG_H

extern const unsigned short peng[256];
#define PENG_SIZE 512
#define PENG_LENGTH 256
#define PENG_WIDTH 16
#define PENG_HEIGHT 16

#endif


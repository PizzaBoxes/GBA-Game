/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 startimg startimg.png 
 * Time-stamp: Monday 04/01/2024, 23:14:00
 * 
 * Image Information
 * -----------------
 * startimg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTIMG_H
#define STARTIMG_H

extern const unsigned short startimg[38400];
#define STARTIMG_SIZE 76800
#define STARTIMG_LENGTH 38400
#define STARTIMG_WIDTH 240
#define STARTIMG_HEIGHT 160

#endif


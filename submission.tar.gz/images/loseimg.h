/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 loseimg loseimg.png 
 * Time-stamp: Tuesday 04/02/2024, 17:39:12
 * 
 * Image Information
 * -----------------
 * loseimg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEIMG_H
#define LOSEIMG_H

extern const unsigned short loseimg[38400];
#define LOSEIMG_SIZE 76800
#define LOSEIMG_LENGTH 38400
#define LOSEIMG_WIDTH 240
#define LOSEIMG_HEIGHT 160

#endif


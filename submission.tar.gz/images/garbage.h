/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 garbage garbage.png 
 * Time-stamp: Monday 04/01/2024, 16:54:48
 * 
 * Image Information
 * -----------------
 * garbage.png 100@75
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GARBAGE_H
#define GARBAGE_H

extern const unsigned short garbage[7500];
#define GARBAGE_SIZE 15000
#define GARBAGE_LENGTH 7500
#define GARBAGE_WIDTH 100
#define GARBAGE_HEIGHT 75

#endif


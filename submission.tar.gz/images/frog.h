/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 frog frog.png 
 * Time-stamp: Monday 04/01/2024, 23:13:11
 * 
 * Image Information
 * -----------------
 * frog.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FROG_H
#define FROG_H

extern const unsigned short frog[256];
#define FROG_SIZE 512
#define FROG_LENGTH 256
#define FROG_WIDTH 16
#define FROG_HEIGHT 16

#endif


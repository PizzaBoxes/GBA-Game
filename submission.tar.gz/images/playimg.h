/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 playimg playimg.png 
 * Time-stamp: Tuesday 04/02/2024, 16:37:44
 * 
 * Image Information
 * -----------------
 * playimg.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PLAYIMG_H
#define PLAYIMG_H

extern const unsigned short playimg[38400];
#define PLAYIMG_SIZE 76800
#define PLAYIMG_LENGTH 38400
#define PLAYIMG_WIDTH 240
#define PLAYIMG_HEIGHT 160

#endif

